var http = require('http');
module.exports = {
    commonService: function (path, method, data, cb) {
        console.log("In node commonService");
        console.log(path);
        console.log(method);
        var options = {
            host: "localhost",
            port: "8080",
            path: path,
            method: method,
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            }
        };
        var req = http.request(options, function (response) {
            response.setEncoding('utf8');
            response.on('data', function (chunk) {
                if (response.statusCode === 404) {
                    log.error(chunk);
                    console.log("In node commonService 404");
                    return cb(false, chunk);
                }
                if (response.statusCode === 500) {
                    log.error(chunk);
                    console.log("In node commonService 500");
                    return cb(false, chunk);
                }
                if (response.statusCode === 200) {
                    console.log("In node commonService 200");
                    log.info(chunk);
                    return cb(false, chunk);
                }
            });
            req.on('error', function (e) {
                log.error(e);
                console.log("In node commonService eeeee");
                return cb(true, e);
            });
        });
        req.on('error', function (e) {
            log.error(e);
            console.log("In node commonService e22222222222");
            return cb(true, e);
        });
        if (method == "post") {
            req.write(data);
        }
        req.end();
    }
}