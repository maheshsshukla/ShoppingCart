var express = require('express');

router = express.Router();

require('./shoppingCart.api');
module.exports = router;


