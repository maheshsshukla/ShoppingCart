/*
 * for constant veriables
 */
var PropertiesReader = require('properties-reader');
var properties = PropertiesReader('application.properties');