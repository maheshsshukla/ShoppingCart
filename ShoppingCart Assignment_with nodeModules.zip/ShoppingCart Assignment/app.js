var express = require('express');
var session = require('express-session');
var bodyParser = require('body-parser');
var initialize = require('express-init');
var cors = require('cors');
var PropertiesReader = require('properties-reader');
var fs = require("fs");

var constants = require('./global.constants');
var logger = require('./logger');

var app = express();
app.set('trust proxy', 1)


//var log = logger.logger;
global.log = logger.logger;
log.debug("Application Started");

//console.log(process.env.public);

var properties = PropertiesReader('application.properties');

// CORS
var corsOptions = {
    origin: '*',
    allowedHeaders: 'Origin, X-Requested-With, Content-Type, Accept, Authorization'
};
app.use(bodyParser.json({limit: '2mb'}));
app.use(bodyParser.urlencoded({limit: '2mb'}));
//express
app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());
log.debug("body parser is set");

app.use(cors(corsOptions));
log.debug("cross fileter activated");

app.use(express.static(__dirname + '/public'));

log.debug("pubic directory middileware function is set for pubilc");

app.get('/serverStatus', function (req, res) {
//    console.log("in server Status");
    res.json({status: "SUCCESS"});
});

//initializer
initialize(app, function (err, cb) {
    if (err)
        console.log(err);
    else {
	// initialize here
    }

    //server
    var portNumber = properties.get('app_port');
    //server
    app.listen(portNumber);
    console.log("server is running on port no " + portNumber);
    log.debug("server is running on port no " + portNumber);
});

// routes
app.use('/api', require('./server/routes/api'));
log.debug("set /api for routes");

app.all('/*', function (req, res, next) {
    res
            .status(200)
            .set({'content-type': 'text/html; charset=utf-8'})
            .sendFile('public/index.html', {root: __dirname});
});

//Error Handling
app.use('UnhandleException',function (err, req, res, next) {
    console.log(err);
    res.sendStatus(500);
});

//Error Handling
process.on('uncaughtException', function (err) {
    console.log(err);
})