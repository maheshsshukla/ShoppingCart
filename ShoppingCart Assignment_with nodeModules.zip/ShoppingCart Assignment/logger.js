/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


//logger

var log4js = require('log4js');
var logger = log4js.getLogger('Cart');

var getLogger = function() {
   return logger;
};

exports.logger = getLogger();
