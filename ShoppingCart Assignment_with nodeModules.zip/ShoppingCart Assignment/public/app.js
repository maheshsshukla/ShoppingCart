var app = angular.module('ShoppingCartApp', ["ngResource", "ngCookies", "ngRoute"]);
app.config(['$routeProvider', '$locationProvider',
    function ($routeProvider, $locationProvider) {
        $locationProvider.html5Mode(false);
        $locationProvider.hashPrefix('!')
        $routeProvider
                .when("/", {
                    templateUrl: "/views/home.html",
                    controller: "HomeController"
                })
                .when("/home", {
                    templateUrl: "/views/home.html",
                    controller: "HomeController"
                })
                .when("/product-info/:id", {
                    templateUrl: "/views/product-info.html",
                    controller: "ProductInfoController"
                })
                .when("/checkout", {
                    templateUrl: "/views/checkout.html",
                    controller: "CheckOutController"
                })
                .otherwise({
                    templateUrl: "/views/ho2me.html",
                    controller: "HomeController"
                });

    }]);

app.run(function ($rootScope, $cookieStore, $location, $http) {
    $rootScope.$on('$routeChangeStart', function (event) {

        var path = $location.path();
        $location.path(path);
    });
});
