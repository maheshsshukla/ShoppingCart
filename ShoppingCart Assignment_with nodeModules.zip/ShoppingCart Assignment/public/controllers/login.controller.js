app.controller('LoginController', function($http, $rootScope, $scope, $location, $cookieStore) {
});