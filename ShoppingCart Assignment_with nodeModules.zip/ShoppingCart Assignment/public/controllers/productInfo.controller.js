app.controller('ProductInfoController', function ($http, $rootScope, $scope, $location, $cookieStore, $routeParams) {
    var id = $routeParams.id;
    $scope.getProductById = function () {
        $http.get('/api/getProduct/' + id).success(function (data, status) {
            $scope.product = JSON.parse(data.data)[0];
            console.log($scope.allProducts);
        }).error(function (data, status) {

        });
    }

    $scope.getCartByUid = function () {
        $http.get('/api/getCart/1').success(function (data, status) {
            $scope.cartSize = JSON.parse(data.data);
        }).error(function (data, status) {

        });
    }
});