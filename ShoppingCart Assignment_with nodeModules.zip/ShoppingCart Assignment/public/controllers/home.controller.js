app.controller('HomeController', function ($http, $rootScope, $scope, $location, $window) {
    $scope.cartData = {};
    
    $scope.getProducts = function () {
        $http.get('/api/getProducts').success(function (data, status) {
            $scope.allProducts = JSON.parse(data.data);
        }).error(function (data, status) {

        });
    }

    $scope.isInCart = function (pid) {
        var flag = false;
        var data = "";
        if ($scope.cart != undefined)
            for (var i = 0; i < $scope.cart.length; i++) {
                if ($scope.cart[i].pid == pid) {
                    flag = true;
                    
                    data = $scope.cart[i];
                    break;
                }
            }
        return flag;
    }
    $scope.getCart = function (pid) {
        var flag = false;
        var data = "";
        if ($scope.cart != undefined)
            for (var i = 0; i < $scope.cart.length; i++) {
                if ($scope.cart[i].pid == pid) {
                    flag = true;
                    data = $scope.cart[i];
                    break;
                }
            }
        return data;
    }

    $scope.getCartByUid = function () {
        $http.get('/api/getCart/1').success(function (data, status) {
            $scope.cart = JSON.parse(data.data);
            $scope.getProducts();
        }).error(function (data, status) {

        });
    }
    $scope.addToCart = function (id) {
        var param = {
            "userid": 1,
            "pid": id,
            "quantity": 1
        }
        $http.post('/api/addToCart', param).success(function (data, status) {
            $scope.getCartByUid();
        }).error(function (data, status) {

        });
    }
    $scope.removeToCart = function (id) {
        var param = {
            "userid": 1,
            "pid": id
        }
        $http.post('/api/removeToCart', param).success(function (data, status) {
            $scope.getCartByUid();
        }).error(function (data, status) {

        });
    }

    $scope.quantityOp = function (status, pid, qt) {
        if (status == "Add") {
            qt++;
        } else {
            qt--;
        }
        var param = {
            "userid": 1,
            "pid": pid,
            "quantity": qt
        }
        $http.post('/api/quantityOp', param).success(function (data, status) {
            $window.location.reload();
        }).error(function (data, status) {

        });

    }

    $scope.setCurretnProduct = function (pid) {
        $scope.currentPid = pid;
    }


});