var commonService = require('../service/common.service');
router.get('/getProducts', function (req, res) {
    commonService.commonService("/product/", "get", "", function (err, response) {
        if (err) {
            res.json({status: 'ERROR', message: response, statusCode: 500});
        } else {
            res.json({status: 'SUCCESS', data: response});
        }
    });
});

router.get('/getProduct/:id', function (req, res) {
    var id = req.param('id');
    commonService.commonService("/product/" + id, "get", "", function (err, response) {
        if (err) {
            res.json({status: 'ERROR', message: response, statusCode: 500});
        } else {
            res.json({status: 'SUCCESS', data: response});
        }
    });
});

router.get('/getCart/:id', function (req, res) {
    var id = req.param('id');
    commonService.commonService("/cart/" + id, "get", "", function (err, response) {
        if (err) {
            res.json({status: 'ERROR', message: response, statusCode: 500});
        } else {
            res.json({status: 'SUCCESS', data: response});
        }
    });
});


router.post('/addToCart', function (req, res) {
    var data = JSON.stringify(req.body);
    commonService.commonService("/cart/addToCart", "post", data, function (err, response) {
        if (err) {
            res.json({status: 'ERROR', message: response, statusCode: 500});
        } else {
            res.json({status: 'SUCCESS', data: response});
        }
    });
});

router.post('/removeToCart', function (req, res) {
    var data = JSON.stringify(req.body);
    commonService.commonService("/cart/removeToCart", "post", data, function (err, response) {
        if (err) {
            res.json({status: 'ERROR', message: response, statusCode: 500});
        } else {
            res.json({status: 'SUCCESS', data: response});
        }
    });
});

router.post('/quantityOp', function (req, res) {
    var data = JSON.stringify(req.body);
    commonService.commonService("/cart/quantityOp", "post", data, function (err, response) {
        if (err) {
            res.json({status: 'ERROR', message: response, statusCode: 500});
        } else {
            res.json({status: 'SUCCESS', data: response});
        }
    });
});