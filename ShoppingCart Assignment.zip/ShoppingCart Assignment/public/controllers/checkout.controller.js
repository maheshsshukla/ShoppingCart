app.controller('CheckOutController', function ($http, $rootScope, $scope, $window, $cookieStore) {


    $scope.cartData = {};
    $scope.allProductsPrice = 0;
    $scope.getProducts = function () {
        $http.get('/api/getProducts').success(function (data, status) {
            $scope.allProducts = JSON.parse(data.data);
            $scope.getTotalPrice();
        }).error(function (data, status) {

        });
    }

    $scope.isInCart = function (p) {
        var flag = false;
        var data = "";
        var pid = p.id;
        if ($scope.cart != undefined)
            for (var i = 0; i < $scope.cart.length; i++) {
                if ($scope.cart[i].pid == pid) {
                    flag = true;
                    data = $scope.cart[i];
                    break;
                }
            }

        return flag;
    }
    $scope.getCart = function (p) {
        var flag = false;
        var data = "";
        var pid = p.id
        if ($scope.cart != undefined)
            for (var i = 0; i < $scope.cart.length; i++) {
                if ($scope.cart[i].pid == pid) {
                    flag = true;
                    data = $scope.cart[i];
                    break;
                }
            }
        return data;
    }

    $scope.getCartByUid = function () {
        $http.get('/api/getCart/1').success(function (data, status) {
            $scope.cart = JSON.parse(data.data);
            $scope.getProducts();
        }).error(function (data, status) {

        });
    }
    $scope.addToCart = function (id) {
        var param = {
            "userid": 1,
            "pid": id,
            "quantity": 1
        }
        $http.post('/api/addToCart', param).success(function (data, status) {
            $scope.getCartByUid();
        }).error(function (data, status) {

        });
    }
    $scope.removeToCart = function (id) {
        var param = {
            "userid": 1,
            "pid": id
        }
        $http.post('/api/removeToCart', param).success(function (data, status) {
            delete $scope.cartProduct[id];
            $scope.getCartByUid();

        }).error(function (data, status) {

        });
    }

    $scope.quantityOp = function (status, pid, qt) {
        if (status == "Add") {
            qt++;
        } else {
            qt--;
        }
        var param = {
            "userid": 1,
            "pid": pid,
            "quantity": qt
        }
        $http.post('/api/quantityOp', param).success(function (data, status) {
            $window.location.reload();
        }).error(function (data, status) {

        });

    }

    $scope.setCurretnProduct = function (pid) {
        $scope.currentPid = pid;
    }

    $scope.getTotalPrice = function () {
        $scope.cartProduct = [];
        $scope.allProductsPrice = 0;
        for (var i = 0; i < $scope.allProducts.length; i++) {
            if ($scope.isInCart($scope.allProducts[i])) {
                var data = $scope.getCart($scope.allProducts[i]);
                $scope.cartProduct.push({p: $scope.allProducts[i],
                    data: data});

                $scope.allProductsPrice += parseInt($scope.allProducts[i].price) * parseInt(data.quantity);
            }
        }



        console.log($scope.cartProduct);

    }
});